
-- Top 5 Customers by Total Spend
SELECT customer_id, SUM(sale_amount) AS total_spent
FROM sales
GROUP BY customer_id
ORDER BY total_spent DESC
LIMIT 5;

-- Monthly Sales Trend
SELECT MONTH(sale_date) AS sale_month, SUM(sale_amount) AS monthly_total
FROM sales
GROUP BY sale_month
ORDER BY sale_month;

-- Top Selling Products
SELECT p.product_name, SUM(s.sale_amount) AS total_sales
FROM sales s
JOIN products p ON s.product_id = p.product_id
GROUP BY p.product_name
ORDER BY total_sales DESC
LIMIT 5;

-- Customer Order Frequency
SELECT customer_id, COUNT(*) AS order_count
FROM sales
GROUP BY customer_id
ORDER BY order_count DESC;

-- Total Revenue
SELECT SUM(sale_amount) AS total_revenue FROM sales;
