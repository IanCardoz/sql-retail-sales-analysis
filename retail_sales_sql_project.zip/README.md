
# Retail Sales Analysis Using SQL

📊 This project demonstrates how to perform real-world data analysis on retail sales data using core SQL skills.

## 📁 Dataset Tables Used:
- `customers`
- `products`
- `sales`

## 🔍 Key Business Questions Answered:
- What are the top-selling products?
- Which month had the highest sales?
- Who are the top 5 customers by total purchase?
- What’s the overall monthly sales trend?

## 🧠 Skills Applied:
- `JOIN` across multiple tables
- `GROUP BY`, `ORDER BY`, `LIMIT`
- Aggregate functions like `SUM()`, `COUNT()`, `AVG()`
- Date formatting and filtering with `WHERE` & `MONTH()`

## 🛠 Sample Query:
```sql
SELECT customer_id, SUM(sale_amount) AS total_spent
FROM sales
GROUP BY customer_id
ORDER BY total_spent DESC
LIMIT 5;
```

## 🎯 Outcome:
Built a clear and modular set of queries that can help decision-makers understand sales performance, customer value, and seasonal patterns.

✅ Ideal for beginner to intermediate SQL learners looking to build a business-oriented SQL analysis project.
